from django.http import HttpResponseRedirect,HttpResponse
from django.shortcuts import render_to_response
from django.core.mail import send_mail
from contacts.forms import ContactForm

#use django.form to rewrite contact, please see the second def of contact
'''
def contact(request):
    error = []
    if request.method == 'POST':
        if not request.POST.get('subject',''):
            error.append('enter a subject')
        #if not request.POST.get('message',''):
        if not request.POST.get('message', ''):
            error.append('enter a message')
        if request.POST.get('email') and '@' not in request.POST['email']:
            error.append('Enter a valid e-mail address.')
        if not error:
            send_mail(request.POST['subject'],request.POST['message'],request.POST.get('email','noreply@django.com'),['yanhua.hit@gmail.com'],)
            return HttpResponseRedirect('/contact/thanks/')
    return render_to_response('contact_form.html',{'error':error,'subject':request.POST.get('subject',''),'message':request.POST.get('message',''),'email':request.POST.get('email','')})
'''

#use django.form to rewrite the contact instead of the above
def contact(request):
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            cd = form.cleaned_data
            send_mail(cd['subject'],cd['message'],cd.get('email','yanhua.hit@gmail.com'),['2587450280@qq.com','gnemoug@gmail.com'],)
            return HttpResponseRedirect('/contact/thanks/')
    else:
        form = ContactForm(initial={'subject':'I love your site'})
    return render_to_response('contact_form.html',{'form':form})
   

