from django.contrib import admin
from douban.models import DoubanBook

class DoubanBookAdmin(admin.ModelAdmin):
    #date_hierarchy = 'publication_date'
    list_display = ('bookname','author','score','publisher','rating_num','five_star','four_star','three_star','two_star','one_star','url','details',)


admin.site.register(DoubanBook,DoubanBookAdmin)

