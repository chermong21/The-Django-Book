from django.db import models


class DoubanBook(models.Model):
    bookname = models.CharField(max_length=100)
    author = models.CharField(max_length = 100,blank=True,null=True)
    publisher = models.CharField(max_length = 300,blank=True,null=True)
    score = models.CharField(max_length=10,blank=True,null=True)
    #page_num = models.CharField(max_length=10,blank=True,null=True)
    #price = models.CharField(max_length=10,blank=True,null=True)
    #publication_date = models.CharField(max_length=10,blank=True,null=True)
    #isbn = models.CharField(max_length = 30,blank=True,null=True)
    rating_num = models.CharField(max_length=10,blank=True,null=True)
    one_star = models.CharField(max_length=10,blank=True,null=True)
    two_star = models.CharField(max_length=10,blank=True,null=True)
    three_star = models.CharField(max_length=10,blank=True,null=True)
    four_star = models.CharField(max_length=10,blank=True,null=True)
    five_star = models.CharField(max_length=10,blank=True,null=True)
    url = models.CharField(max_length=150,blank = True,null=True) 
    details = models.CharField(max_length=1000,blank=True,null=True)

    def __unicode__(self):
        return u'%s %s %s %s %s' %(self.bookname,self.author,self.score,self.five_star,self.four_star)

    class Meta:
        ordering = ['-score','-five_star','-rating_num']

