from django.http import HttpResponse,Http404
import datetime
from django.template.loader import get_template
from django.template import Context
from django.shortcuts import render_to_response


def hello(request):
    return HttpResponse("Hello World!")

'''def current_datetime(request):
    now = datetime.datetime.now()
    html = "<html><body>It is now %s</body></html>" % now
    return HttpResponse(html)
'''
#use get_template() function to get the template
'''def current_datetime(request):
    now = datetime.datetime.now()
    t = get_template('current_datetime.html')
    html = t.render(Context({'current_datetime':now}))
    return HttpResponse(html)
'''
#an example of using render_to_response() to rewrite the veiw current_datetime 
'''def current_datetime(request):
    now = datetime.datetime.now()
    return render_to_response('current_datetime.html',{'current_datetime':now})
'''
#an example of using locals() to return the variable name and its Value 
def current_datetime(request):
    current_datetime = datetime.datetime.now()
    return render_to_response('current_datetime.html',locals())

'''def hours_ahead(request,offset):
    try:
        offset = int(offset)
    except ValueError:
        raise Http404()
    dt = datetime.datetime.now() + datetime.timedelta(hours=offset)
    html = "<html><body>In %s hour(s), it will be %s.</body></html>" % (offset, dt)
    return HttpResponse(html)
'''
def hours_ahead(request,offset):
    try:
        offset = int(offset)
    except ValueError:
        raise Http404()
    hour_ahead = datetime.datetime.now() + datetime.timedelta(hours = offset)
    return render_to_response('hours_ahead.html',{'hour_offset':offset,'next_time':hour_ahead})

#EXERCISE:views to display all the data of request.META
def display_meta(request):
    values = request.META.items()
    values.sort()
    html=[]
    for k,v in values:
        html.append('<tr><td>%s</td><td>%s</td></tr>' % (k, v))
    return HttpResponse('<table>%s</table>' % '\n'.join(html))

